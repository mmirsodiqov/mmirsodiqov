// scripts.js

document.addEventListener('DOMContentLoaded', function() {
    // Sahifa yuklanganda bajariladigan kodlar
    console.log("Sahifa yuklandi.");
});
